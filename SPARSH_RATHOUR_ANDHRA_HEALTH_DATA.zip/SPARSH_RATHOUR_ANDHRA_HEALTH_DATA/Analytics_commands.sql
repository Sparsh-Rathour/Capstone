--SQL query to calculate mortality rates by disease category
SELECT C.CATEGORY_NAME, 
       COUNT(CASE WHEN M.[Mortality_Status] = 'Y' THEN 1 END) AS MortalityCount, 
       COUNT(*) AS TotalCount
FROM Fact_table_ F
INNER JOIN DIM_CATEGORY C ON F.category_id = C.category_key
INNER JOIN DIM_MORTALITY M ON F.mortality_id = M.mortality_id
GROUP BY C.CATEGORY_NAME



--SQL QUERY TO FIND RESTING PERIOD FOR EACH CATEGORY
SELECT avg(DATEDIFF(day,  D.SURGERY_DATE,D.DISCHARGE_DATE)) AS Resting_Period, C.CATEGORY_NAME
FROM DIM_CATEGORY C
LEFT JOIN fact_table_ F ON C.category_key = F.category_id
LEFT JOIN DIM_Date D ON F.date_id = D.Date_id
GROUP BY C.CATEGORY_NAME
ORDER BY Resting_Period ASC


--SQL QUERY TO GET HOSPITAL WITH MIN AMOUNT FOR EACH CATEGORY
SELECT 
    CATEGORY_NAME, 
    HOSP_NAME, 
    MIN_CLAIM_AMOUNT
FROM (
    SELECT 
        CATEGORY_NAME, 
        HOSP_NAME, 
        MIN(CLAIM_AMOUNT) AS MIN_CLAIM_AMOUNT,
        ROW_NUMBER() OVER (PARTITION BY CATEGORY_NAME ORDER BY MIN(CLAIM_AMOUNT) DESC) AS rn
    FROM 
        STG_Andhra_Health_data
    GROUP BY 
        CATEGORY_NAME, 
        HOSP_NAME
) AS SubQuery
WHERE rn = 1
ORDER BY 
    CATEGORY_NAME, 
    MIN_CLAIM_AMOUNT DESC;


--QUERY FOR DEATH COUNT YEAR_MONTH
SELECT 
    [Mortality_Date], 
    COUNT(*) AS DeathCount FROM
DIM_DATE D
LEFT JOIN 
    Fact_table_ F ON D.DATE_ID = F.DATE_id
	LEFT JOIN 
    DIM_Mortality M ON M.Mortality_id = F.mortality_id
WHERE 
    [Mortality_Status] = 'Y'
GROUP BY 
    [Mortality_Date]
ORDER BY 
    [Mortality_Date]


--QUERY FOR TOP 10 LOWERST HOSPITAL DENSITY AREA
sql_query = """
SELECT top 10
    D.DISTRICT_NAME, 
    COUNT(H.hosp_KEY) AS Number_of_Hospitals
FROM 
    DIM_Address D
JOIN 
    fact_table_ ft ON d.Address_Key = ft.address_id
JOIN 
    dim_hospital h ON ft.hospital_id = h.Hosp_Key
GROUP BY 
    d.DISTRICT_NAME
ORDER BY 
    Number_of_Hospitals ASC;
    """