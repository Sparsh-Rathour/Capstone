--STG_ANDHRA_HEALTH_DATA
CREATE TABLE [dbo].[STG_Andhra_Health_data](
	[Sno] [int] PRIMARY KEY,
	[AGE] [int] ,
	[SEX] [varchar](10) ,
	[CASTE_NAME] [varchar](50) ,
	[CATEGORY_CODE] [varchar](50) ,
	[CATEGORY_NAME] [varchar](255) ,
	[SURGERY_CODE] [varchar](50) ,
	[SURGERY] [varchar](255) ,
	[VILLAGE] [varchar](255) ,
	[MANDAL_NAME] [varchar](255) ,
	[DISTRICT_NAME] [varchar](255) ,
	[PREAUTH_DATE] [datetime] ,
	[PREAUTH_AMT] [decimal](10, 2) ,
	[CLAIM_DATE] [datetime] ,
	[CLAIM_AMOUNT] [decimal](10, 2) ,
	[HOSP_NAME] [varchar](255) ,
	[HOSP_TYPE] [varchar](50) ,
	[HOSP_DISTRICT] [varchar](255) ,
	[SURGERY_DATE] [datetime] ,
	[DISCHARGE_DATE] [datetime] ,
	[Mortality] [char](1) ,
	[MORTALITY_DATE] [datetime] ,
	[SRC_REGISTRATION] [varchar](255) )

--DIM_SEX
CREATE TABLE [dbo].[Sex](
	[Sex_Key] [int] PRIMARY KEY,
	[SEX] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )

--DIM_CASTE
CREATE TABLE [dbo].[DIM_Caste](
	[Caste_Key] [int] PRIMARY KEY,
	[Caste] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )

--DIM_SURGERY

--DIM_CATEGORY
CREATE TABLE [dbo].[DIM_Category](
	[Category_Key] [int] PRIMARY KEY,
	[CATEGORY_CODE] [varchar](50) ,
	[CATEGORY_NAME] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )

--DIM_MORTALITY
CREATE TABLE [dbo].[DIM_Mortality](
	[Mortality_id] [int] PRIMARY KEY,
	[Mortality_Status] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )

--DIM_DATE
CREATE TABLE [dbo].[DIM_Date](
	[Date_id] [int] PRIMARY KEY,
	[PREAUTH_DATE] [datetime] ,
	[CLAIM_DATE] [datetime] ,
	[SURGERY_DATE] [datetime] ,
	[DISCHARGE_DATE] [datetime] ,
	[MORTALITY_DATE] [datetime] ,
	[create_date] [datetime] ,
	[update_date] [datetime] )

--DIM_HOSPITAL
CREATE TABLE [dbo].[DIM_Hospital](
	[Hosp_Key] [int] PRIMARY KEY,
	[HOSP_NAME] [varchar](255),
	[HOSP_TYPE] [varchar](50) ,
	[HOSP_DISTRICT] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )
--DIM_ADDRESS
CREATE TABLE [dbo].[DIM_Address](
	[Address_Key] [int] PRIMARY KEY,
	[Village] [varchar](255) ,
	[Mandal_Name] [varchar](50) ,
	[District_Name] [varchar](255) ,
	[create_date] [datetime] ,
	[update_date] [datetime] )
--Fact_table_
CREATE TABLE [dbo].[fact_table_](
	[fact_id] [int] PRIMARY KEY,
	[sex_id] [int] ,
	[caste_id] [int] ,
	[category_id] [int] ,
	[surgery_id] [int] ,
	[Address_id] [int] ,
	[hospital_id] [int] ,
	[Date_id] [int] ,
	[mortality_id] [int] ,
	[age] [int] ,
	[preauth_amount] [int] ,
	[claim_amount] [int] ,
	[create_date] [datetime] ,
	[update_date] [datetime] ,
FOREIGN KEY([Address_id]) REFERENCES [dbo].[DIM_Address] ([Address_Key]),
FOREIGN KEY([caste_id]) REFERENCES [dbo].[DIM_Caste] ([Caste_Key]),
FOREIGN KEY([category_id]) REFERENCES [dbo].[DIM_Category] ([Category_Key]),
FOREIGN KEY([Date_id]) REFERENCES [dbo].[DIM_Date] ([Date_id]),
FOREIGN KEY([hospital_id]) REFERENCES [dbo].[DIM_Hospital] ([Hosp_Key]),
FOREIGN KEY([mortality_id]) REFERENCES [dbo].[DIM_Mortality] ([Mortality_id]),
FOREIGN KEY([sex_id]) REFERENCES [dbo].[DIM_Sex] ([Sex_Key]),
FOREIGN KEY([surgery_id]) REFERENCES [dbo].[DIM_Surgery] ([Surgery_Key]))



